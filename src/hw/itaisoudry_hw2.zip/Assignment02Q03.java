package hw;

/*
 * The idea of this solution is to count the appearances of each digit.
 * Doing that using a sized 9 array, each index represents a digit ( a counter for a digit )
 * After iterating over all the digits from the input, iterating again over the array and printing the digits.
 */
public class Assignment02Q03 {

	public static void main(String[] args) {
		int digit;
		int[] numbersArray = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		// Iterate over the numbers from the input
		for (int i = 0; i < args.length; i++) {
			// Breaks every number into digits and count each digit in the
			// numbers array
			for (int j = 0; j < args[i].length(); j++) {
				digit = Character.getNumericValue(args[i].charAt(j));
				numbersArray[digit]++;
			}

		}
		// If the count for the specific digit is bigger than 0, print it.
		for (int k = 0; k < numbersArray.length; k++) {
			if (numbersArray[k] > 0) {
				System.out.print(k + ":" + numbersArray[k] + " ");
			}
		}
	}

}
