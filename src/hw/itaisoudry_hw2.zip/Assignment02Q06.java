package hw;

import java.util.Arrays;

public class Assignment02Q06 {
	public static void main(String[] args) {
		int[] primes = new int[20];
		primes[0] = 2;
		int num = 3;
		int status = 1;
		int index = 1;
		// The bug was the condition was i<=20 and not index < 20
		for (int i = 2; index < 20; i++) {
			for (int j = 2; j <= Math.sqrt(num); j++) {
				if (num % j == 0) {
					status = 0;
				}
			}
			if (status != 0) {
				primes[index] = num;
				index++;
			}
			status = 1;
			// This will work also with num++, but its a waste of resources, so
			// I changed it to num+=2 for less interations
			num += 2;
		}

		System.out.println(Arrays.toString(primes));
	}
}
