package hw;

public class Assignment02Q01Sec03 {

	public static void main(String[] args) {
		int num, remnant, count = 0;

		for (int i = 0; i < args.length; i++) {
			// Parse number from input
			num = Integer.valueOf(args[i]);
			// Modulo 3
			remnant = num % 3;
			// Check if the remnant is even
			if ((remnant % 2) == 0) {
				// Increment counter
				count++;
			}
		}
		System.out.println(count);

	}

}
