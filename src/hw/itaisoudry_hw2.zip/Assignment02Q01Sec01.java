package hw;

public class Assignment02Q01Sec01 {
	public static void main(String[] args) {
		int character;

		for (int i = 0; i < args.length; i++) {
			// Assuming that every String in args contains only one char
			character = args[i].charAt(0);
			// if the character ascii is even
			if ((character % 2) == 0) {
				// print character - if casting is not allowed yet, it is
				// possible to create another variable char and assign the
				// character to it
				System.out.println((char) character);
			}

		}
	}
}
