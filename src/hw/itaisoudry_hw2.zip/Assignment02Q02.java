package hw;

public class Assignment02Q02 {
	public static void main(String[] args) {
		double radius;

		for (int i = 0; i < args.length; i++) {
			// Parse double from input
			radius = Double.valueOf(args[i]);
			System.out.println("For the: " + i + " argument");
			System.out.println("The Circle area is: " + Math.PI * Math.pow(radius, 2));
			System.out.println("The Circle circumference is: " + radius * 2 * Math.PI);
		}
	}
}
