package hw;

public class Assignment02Q01Sec02 {
	public static void main(String[] args) {
		double num;
		int max = 0;
		for (int i = 0; i < args.length; i++) {
			// Parse double from input
			num = Double.valueOf(args[i]);
			// Check if the number is bigger then the current maximum
			if ((int) num > max) {
				max = (int) num;
			}

		}
		System.out.println(max);

	}
}
