package hw;

import java.util.Arrays;

public class Assignment02Q04 {

	public static void main(String[] args) {
		String finalArr[][] = new String[args.length][];

		for (int i = 0; i < args.length; i++) {
			String[] arr = new String[args[i].length()];
			// Fills the array with the same word. (If this method is not
			// allowed, I would use another for loop to fill up the array)
			Arrays.fill(arr, args[i]);
			finalArr[i] = arr;

		}
		// Prints the two-dimension array
		for (String[] stringArr : finalArr) {
			System.out.println(Arrays.toString(stringArr));
		}
	}

}
